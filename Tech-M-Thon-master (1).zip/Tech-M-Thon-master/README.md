# Tech-M-Thon
Hackathon conducted by GLA University in association with Tech Mahindra.

Rules of Submission,
Use Cases are uploaded as PDF File in this repository which you have to solve over the period of 48 Hours.

**Method I:**

Fork this repository, push your code to the forked repo in your github account, Update solution.txt with your personal credentials & Solved Use Cases.

Alternatively, (for example, In case of not having github account)

**Method II:**

Download this repository, place your code inside, Update solution.txt with your personal credentials & Solved Use Cases, upload the directory or zip file on a google drive and share the link with open access through this google form: https://docs.google.com/forms/d/e/1FAIpQLScoMuSoKDb_fuGWJwqFOWaXL7yzWOZj9Hj4M9uekvB8m5rLIg/viewform?usp=sf_link


Note:

**By Solving 2 or more Use Cases, you can straightaway proceed to next round.**

**By solving only 1 Use Case, Proceeding to next round is based on code review.**

**Teams are free to interpret the use cases based on their skillset. for example, you can submit a jupyter notebook with applied machine learning, Deep Learning or Data Visualisations, you can also submit a full stack based solutions or you can also submit end to end solutions based on your team's skill employing various technologies such as Cloud Deployment or API integration, Full Stack, Data Science, app development etc.**


All The best!
