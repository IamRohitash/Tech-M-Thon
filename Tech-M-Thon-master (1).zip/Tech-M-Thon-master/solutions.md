Team Name:Coding Devs

Use Case 2: Demo File Name in repo if solved otherwise Not Applicable 


Screenshots of live demo (If Any): Screenshot1, Screenshot2, Screenshot3...

Note: 
**File mentioned in screenshots of Use Cases should be inside this repository only.
