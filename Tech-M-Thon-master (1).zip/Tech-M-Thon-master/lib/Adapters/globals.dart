library pct_technician.globals;

import 'package:pcttechnician/Adapters/Technician.dart';

import 'User.dart';

Technician signTechnician;
User scanned;